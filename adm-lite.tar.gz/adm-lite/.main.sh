#!/usr/bin/env sh

				unset soporte slogan
		    soporte=@drowkid01 && slogan="✧ | ᴅʀᴏᴡᴋɪᴅ | ✧"

declare -A sdir=( [banner]="banner" [fpy]="filepy" [fsh]="filesh" [v]="version" [drw]="main" [tmp]=tmp )
declare -A sfile=( [exec]=${sdir[fsh]}/cabecalho.sh [f2b]=${sdir[fsh]}/fai2ban.sh [frm]=${sdir[fsh]}/ferramentas.sh [minst]=${sdir[fsh]}/menu_inst.sh [pyl]=${sdir[fsh]}/payloads [ss]=${sdir[fsh]}/shadowsocks.sh [uht]=${sdir[fsh]}/ultrahost.sh [usr]=${sdir[fsh]}/usercodes.sh [PDirect]=${sdir[fpy]}/PDirect.py [PGet]=${sdir[fpy]}/PGet.py [POpen]=${sdir[fpy]}/POpen.py [PPriv]=${sdir[fpy]}/PPriv.py [PPub]=${sdir[fpy]}/PPub.py [ress]=${sdir[banner]}/message.txt [banner]=${sdir[banner]}/name [main]=main.sh [version]=${sdir[v]}/v-new.log [msg]=${sdir[tmp]}/msg )
declare -A url=( [py]="https://raw.githubusercontent.com/vpsnetdk/ckk/main/exec/filepy" [sh]="https://raw.githubusercontent.com/vpsnetdk/ckk/main/exec/filesh" [main]="https://raw.githubusercontent.com/vpsnetdk/ckk/main/exec/main.sh" [msg]="https://gist.githubusercontent.com/vpsnetdk/a47403148a3f10fbbf645089597f5af7/raw/e902f8fd9a273912379a5b0ea0eb3a6e34f00a91/msg" [utx]="https://raw.githubusercontent.com/vpsnetdk/files-ckk/main" )

init(){
		[[ ! -e "${sfile[main]}" ]] && { wget -O ${sfile[main]} ${url[main]} &> /dev/null && chmod +rwx ${sfile[main]} ; }
			[[ ! -e "${sfile[msg]}" ]] && { mkdir -p ${sdir[tmp]};wget -O ${sfile[msg]} ${url[msg]} &> /dev/null && chmod +rwx ${sfile[msg]} ; }
source ${sfile[main]} && printTitle "Iniciando instalación"

	for rwx in $(echo "sh py"); do
list=`cat <(curl -sSL "${url[$rwx]}/lista$rwx")` && checkdir "${sdir[f$rwx]}"
	     [[ $(ls "${sdir[f$rwx]}") = "" ]] && {
			for arqx in $list; do
				wget -O "${sdir[f$rwx]}/$arqx" ${url[$rwx]}/$arqx &> /dev/null
				chmod +rwx "${sdir[f$rwx]}/$arqx"
			done
	     }
	done

 checkdir "${sdir[banner]}";checkdir "${sdir[v]}"
		[[ ! -e "${sfile[banner]}" ]] && {
			if [[ ! -e "${sfile[ress]}" ]]; then echo "Verified【 $slogan " > ${sfile[ress]} ; fi
		clear;msg -bar;msg -ne "Nombre del servidor:" name
		figlet -f smslant $name > ${sfile[banner]}
		}
 if [[ ! -e "${sfile[version]}" ]]; then echo "versión: 1.0" > ${sfile[version]} ; fi
}
[[ -z $1 ]] && { echo -e "\e[1;31m	ningún parámetro recibido" ; }
case $1 in
 --init ) [[ -z $2 ]] && init
	case $2 in
	"--sources") echo -e "https://donpato.com/elbergas" ;;
	"--general") soporte=@drowkid01 && slogan="✧ | ᴅʀᴏᴡᴋɪᴅ | ✧"
		declare -A sdir=( [banner]="banner" [fpy]="filepy" [fsh]="filesh" [v]="version" [drw]="main" [tmp]=tmp )
		declare -A sfile=( [exec]=${sdir[fsh]}/cabecalho.sh [f2b]=${sdir[fsh]}/fai2ban.sh [frm]=${sdir[fsh]}/ferramentas.sh [minst]=${sdir[fsh]}/menu_inst.sh [pyl]=${sdir[fsh]}/payloads [ss]=${sdir[fsh]}/shadowsocks.sh [uht]=${sdir[fsh]}/ultrahost.sh [usr]=${sdir[fsh]}/usercodes.sh [PDirect]=${sdir[fpy]}/PDirect.py [PGet]=${sdir[fpy]}/PGet.py [POpen]=${sdir[fpy]}/POpen.py [PPriv]=${sdir[fpy]}/PPriv.py [PPub]=${sdir[fpy]}/PPub.py [ress]=${sdir[banner]}/message.txt [banner]=${sdir[banner]}/name [main]=main.sh [version]=${sdir[v]}/v-new.log [msg]=${sdir[tmp]}/msg )
		declare -A url=( [py]="https://raw.githubusercontent.com/vpsnetdk/ckk/main/exec/filepy" [sh]="https://raw.githubusercontent.com/vpsnetdk/ckk/main/exec/filesh" [main]="https://raw.githubusercontent.com/vpsnetdk/ckk/main/exec/main.sh" [msg]="https://gist.githubusercontent.com/vpsnetdk/a47403148a3f10fbbf645089597f5af7/raw/e902f8fd9a273912379a5b0ea0eb3a6e34f00a91/msg" [utx]="https://raw.githubusercontent.com/vpsnetdk/files-ckk/main" )
		;;
	"--drowkid")
		case $3 in
		--link ) echo -e "https://t.me/drowkid01" ;;
		esac
	;;
	esac
;;
# --exec )
#	case $2 in
#	--url ) echo -e ${url[main]} ;;
#	--download ) [[ ! -e "${sfile[msg]}" ]] && wget -O ${sfile[msg]} ${url[msg]} &> /dev/null ;;
#	esac
#;;
esac


